function getPlatformImage(platform) {
  switch (platform) {
    case "XSX":
    case "XBL":
    case "HELIOSMOBILE":
      return "/images/platforms/xBox_PlatformIcon_64x.png";
    case "PS5":
    case "PSN":
      return "/images/platforms/PS4_w-backing_PlatformIcon_64x.png";
    case "MAC":
    case "WIN":
      return "/images/platforms/PC_PlatformIcon_64x.png";
    case "SWT":
      return "/images/platforms/Switch_PlatformIcon_64x.png";
    case "iOS":
    case "AND":
    case "GFNMobile":
      return "/images/platforms/Mobile_PlatformIcon_64x.png";
  }
}

function getPlatformName(platform) {
  const dict = {
    XSX: "Xbox Series X",
    XBL: "Xbox One",
    PS5: "Playstation 5",
    PSN: "Playstation 4",
    MAC: "Mac",
    WIN: "Windows",
    SWT: "Nintendo Switch",
    iOS: "iOS",
    AND: "Android",
    HELIOSMOBILE: "Xbox Cloud Gaming",
    GFNMobile: "GeForce Now",
  };
  return dict[platform];
}

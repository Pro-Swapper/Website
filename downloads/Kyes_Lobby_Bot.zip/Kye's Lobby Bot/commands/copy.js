module.exports = {
  command: "copy",
  handle(message, args) {
    const client = message.client;
    const author = message.author.id;
    if (!client.party.members.has(author)) {
      message.reply("You must be in my party to use this command!");
      return;
    }

    const authorMember = client.party.members.get(author);

    client.party.me.sendPatch({
      "Default:AthenaCosmeticLoadout_j": JSON.stringify(authorMember.meta.get("Default:AthenaCosmeticLoadout_j")),
      "Default:AthenaCosmeticLoadoutVariants_j": JSON.stringify(authorMember.meta.get("Default:AthenaCosmeticLoadoutVariants_j")),
      "Default:AthenaBannerInfo_j": JSON.stringify(authorMember.meta.get("Default:AthenaBannerInfo_j")),
      "Default:BattlePassInfo_j": JSON.stringify(authorMember.meta.get("Default:BattlePassInfo_j")),
    });
  },
};

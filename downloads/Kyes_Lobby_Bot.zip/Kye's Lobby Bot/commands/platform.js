module.exports = {
  command: "platform",
  handle(message, args) {
    const client = message.client;
    client.config.platform = args[1];
    console.log(`Set platform to \x1b[33m${args[1]}\x1b[0m`);
  },
};

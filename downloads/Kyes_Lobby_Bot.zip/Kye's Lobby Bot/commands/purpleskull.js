module.exports = {
  command: "purpleskull",
  handle(message) {
    const client = message.client;
    client.party.me.setOutfit("CID_030_Athena_Commando_M_Halloween", [
      {
        channel: "ClothingColor",
        variant: "Mat1",
      },
    ]);
  },
};

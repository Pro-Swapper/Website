module.exports = {
  command: "pinkghoul",
  handle(message, args) {
    const client = message.client;
    client.party.me.setOutfit("CID_029_Athena_Commando_F_Halloween", [
      {
        channel: "Material",
        variant: "Mat3",
      },
    ]);
  },
};
